(* Paclet Info File *)

(* created 2011/09/06*)

Paclet[
    Name -> "Susyno",
    Version -> "1.1.0",
    MathematicaVersion -> "7+",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Tutorials/SusynoTutorial"}
        }
]


